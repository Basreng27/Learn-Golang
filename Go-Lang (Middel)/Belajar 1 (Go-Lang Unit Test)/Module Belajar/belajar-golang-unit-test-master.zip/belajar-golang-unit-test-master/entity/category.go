package entity

type Category struct {
	Id   string
	Name string
}
