package helper

func HelloWorld(name string) string {
	return "Hello " + name
}
