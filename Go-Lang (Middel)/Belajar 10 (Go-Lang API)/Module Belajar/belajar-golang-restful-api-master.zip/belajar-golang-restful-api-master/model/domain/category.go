package domain

type Category struct {
	Id   int
	Name string
}
