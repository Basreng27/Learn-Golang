package go_say_hello

func SayHello(name string) string {
	return "Hello " + name
}
