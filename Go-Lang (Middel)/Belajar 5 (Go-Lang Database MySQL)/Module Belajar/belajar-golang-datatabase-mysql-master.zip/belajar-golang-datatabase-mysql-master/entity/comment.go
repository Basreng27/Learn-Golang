package entity

type Comment struct {
	Id      int32
	Email   string
	Comment string
}
